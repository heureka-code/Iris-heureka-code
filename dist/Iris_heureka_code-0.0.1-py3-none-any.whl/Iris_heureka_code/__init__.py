from .Event import Event
from .Handler import Handler

__version__ = "0.0.1"
__author__ = "heureka-code"
