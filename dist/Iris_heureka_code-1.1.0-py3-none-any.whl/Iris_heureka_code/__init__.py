from .Event import Event
from .Handler import Handler
from .StaticHandler import StaticHandler

__version__ = "1.0.0"
__author__ = "heureka-code"
